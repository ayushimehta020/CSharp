﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class ViewStudent : Form
    {
        int ind = 0;
        int tr = 0;
        string aadhar = String.Empty;
        string gender = String.Empty;
        DataTable dt1 = new DataTable();
        public ViewStudent()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void ViewStudent_Load(object sender, EventArgs e)
        {
            string sql = "select * from stud";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            da.Fill(dt1);
            tr = dt1.Rows.Count - 1;
            if (dt1.Rows.Count > 0)
            {
                disp();
            }
        }

        private void disp()
        {
            textBox3.Text = dt1.Rows[ind][3].ToString();
            textBox4.Text = dt1.Rows[ind][0].ToString();
            textBox5.Text = dt1.Rows[ind][1].ToString();
            dateTimePicker1.Text = dt1.Rows[ind][2].ToString();
            comboBox1.Text = dt1.Rows[ind][6].ToString();
            textBox6.Text = dt1.Rows[ind][4].ToString();
            if (dt1.Rows[ind][5].ToString() == "m")
            {
                radioButton1.Checked = true;
            }
            else if (dt1.Rows[ind][5].ToString() == "f")
            {
                radioButton2.Checked = true;
            }
            else if (dt1.Rows[ind][5].ToString() == "a")
            {
                radioButton3.Checked = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ind = 0;
            disp();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ind < tr)
            {
                ind++;
                disp();
            }
            else
            {
                MessageBox.Show("LAST");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ind > 0)
            {
                ind--;
                disp();
            }
            else
            {
                MessageBox.Show("FIRST");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ind = tr;
            if (ind > 0)
            {
                disp();
            }
        }
    }
}
