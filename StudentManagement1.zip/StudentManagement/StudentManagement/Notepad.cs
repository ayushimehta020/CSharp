﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Notepad : Form
    {
        string fileName = String.Empty;
        string originalFilePath = String.Empty;
        public Notepad()
        {
            InitializeComponent();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "My Notepad Open File";
            ofd.InitialDirectory = "C:\\Ayushi\\StudentManagement\\StudentManagement";
            ofd.Filter = "Text files | *.txt";
            ofd.ShowDialog();
            if (ofd.FileName != "")
            {
                richTextBox1.LoadFile(ofd.FileName);
            }
        }

        private void textColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            richTextBox1.ForeColor = cd.Color;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            richTextBox1.Font = fd.Font;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a  = Convert.ToInt32(MessageBox.Show("Do You Want To Save Your File?", "My Notepad", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
            if (a == 6)
            {
                saveFile();
            }
            else
            {
                richTextBox1.Text = "";
            }
        }

        private void saveFile()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "txt";
            sfd.Title = "My Notepad Save File";
            sfd.InitialDirectory = "C:\\Ayushi\\StudentManagement\\StudentManagement";
            sfd.Filter = "Text files | *.txt";
            if (fileName == "")
            {
                sfd.ShowDialog();
                if (sfd.FileName == "")
                {
                    richTextBox1.SaveFile(fileName);
                }
                fileName = sfd.FileName;
            }
            else
            {
                richTextBox1.SaveFile(fileName);
            }
        }
    }
}
