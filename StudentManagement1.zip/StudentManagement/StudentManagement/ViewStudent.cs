﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class ViewStudent : Form
    {
        DataTable dt1 = new DataTable();

        public ViewStudent()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                string sql = "select * from stud where aadhar_no like '" + textBox1.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                dt1.Clear();
                da.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    listBox1.Visible = true;
                    listBox1.Items.Clear();
                    for (int i = 0; i < dt1.Rows.Count; i++)
                    {
                        listBox1.Items.Add(dt1.Rows[i][0].ToString());
                    }
                    dataGridView1.DataSource = dt1;
                }
                else
                {
                    listBox1.Visible = false;
                    textBox2.Text = "No Data Found!";
                    dataGridView1.DataSource = null;
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ind = listBox1.SelectedItem.ToString();
            listBox1.Visible = false;
            textBox2.Text = ind;
        }
    }
}
