﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            btnClose.Location = new Point((this.Width - btnClose.Width) - 3, 0);
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BSCIT.checkPage = 0;
            Student S1 = new Student();
            S1.Show();
        }

        private void selectStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BSCIT.checkPage = 1;
            Student S1 = new Student();
            S1.Show();
        }

        private void updateStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BSCIT.checkPage = 2;
            Student S1 = new Student();
            S1.Show();
        }

        private void deleteStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BSCIT.checkPage = 3;
            Student S1 = new Student();
            S1.Show();
        }
    }
}
