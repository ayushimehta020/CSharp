﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student
{
    public partial class Admin : Form
    {
        string unm = string.Empty;
        public Admin()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void checkText()
        {
            if (linkLbl1.Text == "New account? Register")
            {
                linkLbl1.Text = "Already a user? Login";
                btn1.Text = "Register";
                linkLbl1.Location = new Point(129, 212);
                txtunm.Text = txtpwd.Text = string.Empty;
            }
            else
            {
                linkLbl1.Text = "New account? Register";
                btn1.Text = "Login";
                linkLbl1.Location = new Point(120, 212);
                txtunm.Text = txtpwd.Text = string.Empty;
            }
        }

        private void linkLbl1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            checkText();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (btn1.Text == "Register")
            {
                if (unm == "y")
                {
                    if (txtunm.Text != "" && txtpwd.Text != "")
                    {
                        string sql = "insert into admin_login values('" + txtunm.Text + "', '" + txtpwd.Text + "')";
                        SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        checkText();
                        txtunm.Text = txtpwd.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show("Enter Valid Values!", "Admin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtunm.Text = txtpwd.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("Username already exists!", "Admin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtunm.Text = txtpwd.Text = string.Empty;
                }
            }
            else
            {
                if (txtunm.Text != "" && txtpwd.Text != "")
                {
                    string sql = "select * from admin_login where username='" + txtunm.Text + "' and password='" + txtpwd.Text + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count == 1)
                    {
                        Home home = new Home();
                        home.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password!", "Admin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtunm.Text = txtpwd.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show("Enter Valid Values!", "Admin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtunm.Text = txtpwd.Text = string.Empty;
                }
            }
        }

        private void txtunm_KeyUp(object sender, KeyEventArgs e)
        {
            if (btn1.Text == "Register")
            {
                string sql = "select * from admin_login where username='" + txtunm.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    txtunm.ForeColor = Color.Green;
                    unm = "y";
                }
                else
                {
                    txtunm.ForeColor = Color.Red;
                    unm = "n";
                }
            }
            else
            {
                txtunm.ForeColor = txtpwd.ForeColor = Color.Black;
            }
        }
    }
}
