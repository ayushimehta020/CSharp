﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student
{
    public partial class License : Form
    {
        public License()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void License_Load(object sender, EventArgs e)
        {
            string sql = "select * from LicenseKey";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBox1.Text = dt.Rows[0][1].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from LicenseKey";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string licenseKey = textBox2.Text;
            int basicKey = Convert.ToInt32(dt.Rows[0][1]);
            int licenseKeyInt = basicKey * 2;
            if (Convert.ToInt64(licenseKey) == licenseKeyInt)
            {
                string sql1 = "update LicenseKey set licenseKey='" + licenseKey + "'";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, BSCIT.cn);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                this.Hide();
                Admin A = new Admin();
                A.Show();
            }
            else
            {
                MessageBox.Show("Invalid!", "License", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
