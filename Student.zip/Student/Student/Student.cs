﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student
{
    public partial class Student : Form
    {
        string id = string.Empty;
        int tr;
        int ind = 0;
        string rb = string.Empty;
        string filename = string.Empty;
        string filename1 = string.Empty;
        public Student()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Student_Load(object sender, EventArgs e)
        {
            if (BSCIT.checkPage == 0)
            {
                btnFirst.Visible = false;
                btnNext.Visible = false;
                btnPrev.Visible = false;
                btnLast.Visible = false;
                btnOpen.Visible = true;
            }
            else if (BSCIT.checkPage == 1)
            {
                btnSave.Visible = false;
            }
            else if (BSCIT.checkPage == 2)
            {
                btnSave.Text = "Update Student";
            }
            else
            {
                btnSave.Text = "Delete Student";
            }
            getData();
        }

        private void clear()
        {
            if (BSCIT.checkPage == 0 || BSCIT.checkPage == 3)
            {
                if (tr <= 0 || BSCIT.checkPage == 0)
                {
                    txtId.Text = txtName.Text = string.Empty;
                    dtDob.Value = DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));
                    cmbCourse.Text = "-- SELECT COURSE --";
                    pictureBox1.Image = null;
                    rbMale.Checked = true;
                }
            }
        }

        private void getData()
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            dtDob.MaxDate = DateTime.Now;
            string sql = "select * from stud_details";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            tr = dt.Rows.Count - 1;
            if (BSCIT.checkPage == 0)
            {
                if (dt.Rows.Count == 0)
                {
                    id = "EMP0001";
                    txtId.Text = id;
                }
                else
                {
                    int tr = dt.Rows.Count - 1;
                    string oldId = dt.Rows[tr][0].ToString();
                    string cid = oldId.Substring(3);
                    int newId = Convert.ToInt32(cid) + 1;
                    txtId.Text = "EMP" + newId.ToString("0000");
                    id = txtId.Text;
                }
            }
            else
            {
                if (dt.Rows.Count > 0)
                {
                    txtId.Text = dt.Rows[ind][0].ToString();
                    txtName.Text = dt.Rows[ind][1].ToString();
                    pictureBox1.Image = System.Drawing.Image.FromFile(dt.Rows[ind][2].ToString());
                    cmbCourse.Text = dt.Rows[ind][3].ToString();
                    dtDob.Text = dt.Rows[ind][4].ToString();
                    if (dt.Rows[ind][5].ToString() == "M")
                    {
                        rbMale.Checked = true;
                    }
                    else
                    {
                        rbFemale.Checked = true;
                    }
                }
                else
                {
                    if (btnSave.Text != "Add Student")
                    {
                        btnFirst.Enabled = false;
                        btnNext.Enabled = false;
                        btnPrev.Enabled = false;
                        btnLast.Enabled = false;
                        btnSave.Enabled = false;
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sql = string.Empty;
            string msg = string.Empty;
            if (btnSave.Text == "Add Student")
            {
                if (txtName.Text.Trim() != "" && cmbCourse.Text != "-- SELECT COURSE --" && filename != "")
                {
                    string oldpath = Application.StartupPath.ToString() + @"\images\";
                    string fPath = oldpath + filename1;
                    pictureBox1.Image.Save(fPath);
                    rb = rbMale.Checked ? "M" : "F";
                    sql = "insert into stud_details values('" + txtId.Text + "', '" + txtName.Text + "', '" + fPath + "', '" + cmbCourse.Text + "', '" + dtDob.Text + "', '" + rb + "')";
                    msg = "Inserted!";
                }
                else
                {
                    MessageBox.Show("Enter Valid Values!", "Student", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    sql = string.Empty;
                }
            }
            else if (btnSave.Text == "Update Student")
            {
                if (txtName.Text.Trim() != "" && cmbCourse.Text != "-- SELECT COURSE --")
                {
                    sql = "update stud_details set stud_id='" + txtId.Text + "', stud_name='" + txtName.Text + "', course='" + cmbCourse.Text + "', dob='" + dtDob.Text + "', gender='" + rb + "' where stud_id='" + txtId.Text + "'";
                    msg = "Updated!";
                    ind = 0;
                }
                else
                {
                    MessageBox.Show("Enter Valid Values!", "Student", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    sql = string.Empty;
                }
            }
            else if (btnSave.Text == "Delete Student")
            {
                sql = "delete from stud_details where stud_id='" + txtId.Text + "'";
                msg = "Deleted!";
                ind = 0;
            }
            if (sql != string.Empty)
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                MessageBox.Show(msg, "Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clear();
                getData();
            }

            if (tr < 0)
            {
                if (btnSave.Text == "Update Student" || btnSave.Text == "Delete Employee")
                {
                    btnSave.Enabled = false;
                }
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog OD = new OpenFileDialog();
            OD.Filter = "Image Files | *.jpeg;*.png;*.jpg";
            OD.ShowDialog();
            if (OD.FileName != "")
            {
                Random rd = new Random();
                string random = rd.Next().ToString();
                filename = OD.FileName;
                string newfilename = filename.Substring(filename.LastIndexOf("."));
                string tempname = "TEMP" + random + newfilename;
                filename1 = tempname;
                pictureBox1.Image = System.Drawing.Image.FromFile(OD.FileName);
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            if (tr > 0)
            {
                ind = 0;
                getData();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (ind < tr)
            {
                ind++;
                getData();
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (ind > 0)
            {
                ind--;
                getData();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            if (tr > 0)
            {
                ind = tr;
                getData();
            }
        }
    }
}
