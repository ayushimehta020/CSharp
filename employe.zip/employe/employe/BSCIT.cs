﻿using System;
using System.Collections.Generic;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace employe
{
    class BSCIT
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\abc_org.mdf;Integrated Security=True;User Instance=True");
    }
}
