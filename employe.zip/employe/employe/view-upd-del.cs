﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace employe
{
    public partial class view_upd_del : Form
    {
        DataTable dt1 = new DataTable();
        string id;
        string id1;

        public view_upd_del()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                string sql = "select * from emp_details where emp_id like '" + textBox1.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                dt1.Clear();
                da.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    listBox1.Visible = true;
                    listBox1.Items.Clear();
                    for (int i = 0; i < dt1.Rows.Count; i++)
                    {
                        listBox1.Items.Add(dt1.Rows[i][0]);
                    }
                }
                else
                {
                    listBox1.Visible = false;
                    textBox2.Text = "No Records Found!";
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = listBox1.SelectedItem.ToString();
            string name = dt1.Rows[0][1].ToString();
            listBox1.Visible = false;
            string sql = "select * from emp_details where emp_id='" + id + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBox2.Text = dt.Rows[0][1].ToString();
            if (dt.Rows.Count > 0)
            {
                textBox3.Text = dt.Rows[0][0].ToString();
                textBox4.Text = dt.Rows[0][1].ToString();
                comboBox1.Text = dt.Rows[0][2].ToString();
                dateTimePicker1.Text = dt.Rows[0][3].ToString();
                textBox5.Text = dt.Rows[0][4].ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (id1 == "y" && textBox4.Text.Length > 0 && comboBox1.SelectedIndex > -1 && textBox5.Text.Length > 0)
            {
                try
                {
                    int a = Convert.ToInt32(MessageBox.Show("Do You Want To Update The Record?", "Employee Management", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
                    if (a == 6)
                    {
                        string sql = "update emp_details set emp_id='" + textBox3.Text + "', emp_name='" + textBox4.Text + "', emp_dept='" + comboBox1.Text + "', join_date='" + dateTimePicker1.Text + "', salary='" + textBox5.Text + "' where emp_id='" + id + "'";
                        SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        MessageBox.Show("Record Updated Successfully!");
                        textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = String.Empty;
                        comboBox1.Text = "-- SELECT DEPARTMENT --";
                        dateTimePicker1.Value = DateTime.Now;
                    }
                }
                catch
                {
                    MessageBox.Show("Record Cannot Be Updated!");
                }
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            string sql = "select * from emp_details where emp_id='" + id + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 1)
            {
                textBox3.ForeColor = Color.Red;
                id1 = "n";
            }
            else
            {
                textBox3.ForeColor = Color.Green;
                id1 = "y";
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(MessageBox.Show("Do You Want To Delete The Record?", "Employee Management", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
                if (a == 6)
                {
                    string sql = "delete from emp_details where emp_id='" + id + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    MessageBox.Show("Record Deleted Successfully!");
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = string.Empty;
                    comboBox1.Text = "-- SELECT DEPARTMENT --";
                    dateTimePicker1.Value = DateTime.Now;
                }
            }
            catch
            {
                MessageBox.Show("Record Cannot Be Deleted!");
            }
        }
    }
}
