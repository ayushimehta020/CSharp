﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace employe
{
    public partial class addemp : Form
    {
        string id;

        public addemp()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string sql = "select * from emp_details where emp_id='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                textBox1.ForeColor = Color.Red;
                id = "n";
            }
            else
            {
                textBox1.ForeColor = Color.Green;
                id = "y";
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void rectangleShape1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label8.Visible = true;
            if (id == "y" && textBox2.Text.Length > 0 && textBox3.Text.Length > 0 && comboBox1.SelectedIndex > -1)
            {
                try
                {
                    string sql = "insert into emp_details values('" + textBox1.Text + "', '" + textBox2.Text + "', '" + comboBox1.Text + "', '" + dateTimePicker1.Text + "', '" + textBox3.Text + "')";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    label8.ForeColor = Color.Green;
                    label8.Text = "Record Inserted Successfully!";
                    textBox1.Text = textBox2.Text = textBox3.Text = String.Empty;
                    comboBox1.Text = "-- SELECT DEPARTMENT --";
                    dateTimePicker1.Value = DateTime.Now;
                }
                catch
                {
                    label8.ForeColor = Color.Red;
                    label8.Text = "Record Cannot Be Inserted!";
                }
            }
            else
            {
                label8.ForeColor = Color.Red;
                label8.Text = "Enter Valid Values!";
            }
        }

        //private void addemp_Load(object sender, EventArgs e)
        //{
        //    label8.Left = 10;
        //    label8.Width = this.Width - 10;
        //}

        private void label8_SizeChanged(object sender, EventArgs e)
        {
            label8.Left = (this.Width - label8.Width) / 2;
        }
    }
}
