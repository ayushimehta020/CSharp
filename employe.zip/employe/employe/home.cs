﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace employe
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void home_Load(object sender, EventArgs e)
        {
            button1.Location = new Point((this.Width - button1.Width) - 5, 0);
        }

        private void addEmployeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addemp emp = new addemp();
            emp.Show();
        }

        private void viewEmployeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            view_upd_del viewEmp = new view_upd_del();
            viewEmp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
