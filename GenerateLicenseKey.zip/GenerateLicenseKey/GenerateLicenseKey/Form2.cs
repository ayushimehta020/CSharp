﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateLicenseKey
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Ayushi\\C#\\WindowsApplications\\GenerateLicenseKey\\GenerateLicenseKey\\bin\\Debug\\LicenseKey.mdf;Integrated Security=True");
            string sql = "select * from ChkLicense";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBox1.Text = dt.Rows[0][1].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Ayushi\\C#\\WindowsApplications\\GenerateLicenseKey\\GenerateLicenseKey\\bin\\Debug\\LicenseKey.mdf;Integrated Security=True");
            string sql = "select * from ChkLicense";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string licenseKey = textBox2.Text;
            int basicKey = Convert.ToInt32(dt.Rows[0][1]);
            int licenseKeyInt = basicKey * 2;
            if (Convert.ToInt64(licenseKey) == licenseKeyInt)
            {
                string sql1 = "update ChkLicense set licenseKey='" + licenseKey + "'";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, cn);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                this.Hide();
                Form1 F1 = new Form1();
                F1.Show();
            }
            else
            {
                MessageBox.Show("Invalid!", "MyApp", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
