﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateLicenseKey
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Ayushi\\C#\\WindowsApplications\\GenerateLicenseKey\\GenerateLicenseKey\\bin\\Debug\\LicenseKey.mdf;Integrated Security=True");
            string sql = "select * from ChkLicense";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Random rd = new Random();
            string basicKey = rd.Next().ToString();
            if (ds.Tables[0].Rows.Count == 0)
            {
                string sql1 = "insert into ChkLicense values('0', '" + basicKey + "', '')";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, cn);
                DataTable dt = new DataTable();
                da1.Fill(dt);
            }
            else
            {
                if (ds.Tables[0].Rows[0][2].ToString() == "")
                {
                    int count = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                    if (count < 10)
                    {
                        count++;
                        string sql1 = "update ChkLicense set count='" + count + "'";
                        SqlDataAdapter da1 = new SqlDataAdapter(sql1, cn);
                        DataTable dt = new DataTable();
                        da1.Fill(dt);
                    }
                    else
                    {
                        int a = Convert.ToInt32(MessageBox.Show("Key expired. Do you have License Key?", "MyApp", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
                        if (a == 6)
                        {
                            this.Hide();
                            Form2 F2 = new Form2();
                            F2.Show();
                        }
                        else
                        {
                            Application.Exit();
                        }
                    }
                }
            }
        }
    }
}
