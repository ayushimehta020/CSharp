﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Student : Form
    {
        string aadhar = "";
        string mobile = "";
        string gender = "";
        string course = "";
        string city = "";
        string name = "";
        
        public Student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string sql = "select * from stud where aadhar_no='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (textBox1.Text.Length == 12)
            {
                if (dt.Rows.Count == 1)
                {
                    textBox1.ForeColor = Color.Red;
                    aadhar = "n";
                }
                else
                {
                    textBox1.ForeColor = Color.Green;
                    aadhar = "y";
                }
            }
            else
            {
                textBox1.ForeColor = Color.Yellow;
                aadhar = "n";
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox3.Text.Length == 10)
            {
                textBox3.ForeColor = Color.Green;
                mobile = "y";
            }
            else
            {
                textBox3.ForeColor = Color.Red;
                mobile = "n";
            }
        }

        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox2.Text.Length > 0)
            {
                name = "y";
            }
            else
            {
                name = "n";
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0)
            {
                city = "y";
            }
            else
            {
                city = "n";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                course = "y";
            }
            else
            {
                course = "n";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (aadhar == "y" && mobile == "y" && city == "y" && name == "y" && course == "y")
            {
                if (radioButton1.Checked)
                {
                    gender = "m";
                }
                if (radioButton2.Checked)
                {
                    gender = "f";
                }
                if (radioButton3.Checked)
                {
                    gender = "a";
                }
                try
                {
                    string sql = "insert into stud values('" + textBox2.Text + "', '" + textBox1.Text + "', '" + textBox3.Text + "', '" + textBox4.Text + "', '" + dateTimePicker1.Value.ToShortDateString() + "', '" + comboBox1.Text + "', '" + gender + "')";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    MessageBox.Show("Record Inserted Successfully!");
                }
                catch
                {
                    MessageBox.Show("Record Cannot Be Inserted!");
                }
            }
            else
            {
                MessageBox.Show("Enter valid values!");
            }
        }
    }
}
