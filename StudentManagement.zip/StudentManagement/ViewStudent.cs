﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class ViewStudent : Form
    {
        string aadhar;
        string gender;
        string ind;
        DataTable dt1 = new DataTable();
        public ViewStudent()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text.Length != 0)
            {
                string sql = "select * from stud where aadhar_no like '" + textBox1.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                dt1.Clear();
                da.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    listBox1.Visible = true;
                    listBox1.Items.Clear();
                    for (int i = 0; i < dt1.Rows.Count; i++)
                    {
                        listBox1.Items.Add(dt1.Rows[i][0]);
                    }
                }
                else
                {
                    listBox1.Visible = false;
                    textBox2.Text = "No Records Found!";
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ind = listBox1.SelectedItem.ToString();
            listBox1.Visible = false;
            textBox2.Text = ind;
            string sql = "select * from stud where stud_name='" + ind + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBox3.Text = dt.Rows[0][3].ToString();
            textBox4.Text = dt.Rows[0][0].ToString();
            textBox5.Text = dt.Rows[0][1].ToString();
            dateTimePicker1.Text = dt.Rows[0][2].ToString();
            comboBox1.Text = dt.Rows[0][6].ToString();
            textBox6.Text = dt.Rows[0][4].ToString();
            if (dt.Rows[0][5].ToString() == "m")
            {
                radioButton1.Checked = true;
            }
            else if (dt.Rows[0][5].ToString() == "f")
            {
                radioButton2.Checked = true;
            }
            else if (dt.Rows[0][5].ToString() == "a")
            {
                radioButton3.Checked = true;
            }
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (aadhar == "y" && textBox4.Text.Length > 0 && textBox6.Text.Length > 0 && textBox5.Text.Length == 10)
            {
                if (radioButton1.Checked)
                {
                    gender = "m";
                }
                else if (radioButton2.Checked)
                {
                    gender = "f";
                }
                else if (radioButton3.Checked)
                {
                    gender = "a";
                }
                string sql = "update stud set stud_name='" + textBox4.Text + "', mob_no='" + textBox5.Text + "', dob='" + dateTimePicker1.Text + "', aadhar_no='" + textBox3.Text + "', city='" + textBox6.Text + "', gender='" + gender + "', course='" + comboBox1.Text + "' where stud_name='" + textBox2.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                MessageBox.Show("Record Updated Successfully!");
            }
            else
            {
                MessageBox.Show("Enter Valid Values!");
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            string sql = "select * from stud where aadhar_no='" + textBox3.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (textBox3.Text.Length == 12)
            {
                if (dt.Rows.Count > 1)
                {
                    textBox3.ForeColor = Color.Red;
                    aadhar = "n";
                }
                else
                {
                    textBox3.ForeColor = Color.Green;
                    aadhar = "y";
                }
            }
            else
            {
                textBox3.ForeColor = Color.Yellow;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
