﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EmployeeConnectivity
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from admin_login where username='" + txtUnm.Text + "' and password='" + txtPwd.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                Home HP = new Home();
                HP.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
