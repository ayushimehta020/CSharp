﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EmployeeConnectivity
{
    public partial class Employee : Form
    {
        int ind = 0;
        int tr;
        
        public Employee()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void Employee_Load(object sender, EventArgs e)
        {
            if (BSCIT.checkPage == 0)
            {
                btnFirst.Visible = false;
                btnNext.Visible = false;
                btnPrev.Visible = false;
                btnLast.Visible = false;
            }
            else if (BSCIT.checkPage == 1)
            {
                btnSave.Visible = false;
            }
            else if (BSCIT.checkPage == 2)
            {
                btnSave.Text = "Update Employee";
            }
            else
            {
                btnSave.Text = "Delete Employee";
            }
            getData();
        }
        private void getData()
        {
            dtJoin.MaxDate = DateTime.Now;
            string sql = "select * from emp_details";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            tr = dt.Rows.Count - 1;
            if (BSCIT.checkPage == 0)
            {
                if (tr == -1)
                {
                    txtId.Text = "EMP0001";
                }
                string oldId = dt.Rows[tr][0].ToString();
                string cid = oldId.Substring(3);
                int newId = Convert.ToInt32(cid) + 1;
                // MessageBox.Show(cid.ToString());

                if (tr < 8)
                {
                    txtId.Text = "EMP000" + newId;
                }
                else if (tr >= 8)
                {
                    txtId.Text = "EMP00" + newId;
                }
            }
            else
            {
                tr = dt.Rows.Count - 1;
                if (tr >= 0)
                {
                    txtId.Text = dt.Rows[ind][0].ToString();
                    txtEname.Text = dt.Rows[ind][1].ToString();
                    cmbDept.Text = dt.Rows[ind][2].ToString();
                    dtJoin.Text = dt.Rows[ind][3].ToString();
                    txtSal.Text = dt.Rows[ind][4].ToString();
                }
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (BSCIT.checkPage == 0)
            {
                if (txtEname.Text != "" && txtSal.Text != "" && cmbDept.Text != "-- SELECT DEPARTMENT --")
                {
                    string sql = "insert into emp_details values('" + txtId.Text + "', '" + txtEname.Text + "', '" + cmbDept.Text + "', '" + dtJoin.Text + "', '" + txtSal.Text + "')";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    MessageBox.Show("Record Inserted Successfully!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEname.Text = txtId.Text = txtSal.Text = string.Empty;
                    getData();
                    cmbDept.Text = "-- SELECT DEPARTMENT --";
                    dtJoin.Text = DateTime.Now.ToString();
                }
                else
                {
                    MessageBox.Show("Enter Valid Values!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (tr >= 0)
            {
                if (BSCIT.checkPage == 2)
                {
                    if (txtEname.Text != "" && txtSal.Text != "")
                    {
                        string sql = "update emp_details set emp_name='" + txtEname.Text + "', department='" + cmbDept.Text + "', join_date='" + dtJoin.Text + "', salary='" + txtSal.Text + "' where id='" + txtId.Text + "'";
                        SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        MessageBox.Show("Record Updated Successfully!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Enter Valid Values!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (BSCIT.checkPage == 3)
                {
                    string sql = "delete from emp_details where id='" + txtId.Text + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    MessageBox.Show("Record Deleted Successfully!", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEname.Text = txtId.Text = txtSal.Text = string.Empty;
                    getData();
                    cmbDept.Text = "-- SELECT DEPARTMENT --";
                    dtJoin.Text = DateTime.Now.ToString();
                }
            }
            else
            {
                btnSave.Enabled = false;
            }
        }
        private void btnFirst_Click(object sender, EventArgs e)
        {
            ind = 0;
            if (tr > 0)
            {
                getData();
            }
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            ind++;
            if (ind <= tr)
            {
                getData();
            }
            else
            {
                MessageBox.Show("LAST");
            }
        }
        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (ind > 0)
            {
                ind--;
                getData();
            }
            else
            {
                MessageBox.Show("FIRST");
            }
        }
        private void btnLast_Click(object sender, EventArgs e)
        {
            ind = tr;
            if (tr >= 0)
            {
                getData();
            }
        }
    }
}
